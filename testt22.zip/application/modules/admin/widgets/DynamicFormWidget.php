<?php

namespace app\modules\admin\widgets;

use app\modules\admin\assets\DynamicFormAsset;
use yii\web\View;
use yii\base\Model;
use yii\db\ActiveRecord;
use yii\helpers\Json;
use yii\helpers\Html;
use yii\base\InvalidConfigException;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package app\modules\admin\widgets
 */
class DynamicFormWidget extends \yii\base\Widget
{
    const HASH_VAR_BASE_NAME = 'dynamicform_';
    /**
     * @var string
     */
    public $widgetContainer;
    /**
     * @var string
     */
    public $widgetBody;
    /**
     * @var string
     */
    public $widgetItem;
    /**
     * @var string
     */
    public $limit = 999;
    /**
     * @var string
     */
    public $insertButton;
    /**
     * @var string
     */
    public $deleteButton;
    /**
     * @var string 'bottom' or 'top';
     */
    public $insertPosition = 'bottom';
    /**
     * @var Model|ActiveRecord the model used for the form
     */
    public $model;
    /**
     * @var string form ID
     */
    public $formId;
    /**
     * @var array fields to be validated.
     */
    public $formFields;
    /**
     * @var integer
     */
    public $min = 1;
    /**
     * @var string
     */
    public $template;
    /**
     * @var array
     */
    private $_options = [];
    /**
     * @var array
     */
    private $_insertPositions = ['bottom', 'top'];
    /**
     * @var string the hashed global variable name storing the pluginOptions
     */
    private $_hashVar;

    /**
     * Initializes the widget
     *
     * @throws \yii\base\InvalidConfigException
     */
    public function init()
    {
        parent::init();
        if (empty($this->widgetBody)) {
            throw new InvalidConfigException("The 'widgetBody' property must be set.");
        }
        if (empty($this->widgetItem)) {
            throw new InvalidConfigException("The 'widgetItem' property must be set.");
        }
        if (empty($this->model) || !$this->model instanceof \yii\base\Model) {
            throw new InvalidConfigException("The 'model' property must be set and must extend from '\\yii\\base\\Model'.");
        }
        if (empty($this->formId)) {
            throw new InvalidConfigException("The 'formId' property must be set.");
        }
        if (empty($this->insertPosition) || !in_array($this->insertPosition, $this->_insertPositions)) {
            throw new InvalidConfigException("Invalid configuration to property 'insertPosition' (allowed values: 'bottom' or 'top')");
        }
        if (empty($this->formFields) || !is_array($this->formFields)) {
            throw new InvalidConfigException("The 'formFields' property must be set.");
        }
        $this->initOptions();
    }

    /**
     * Initializes the widget options
     */
    protected function initOptions()
    {
        $this->_options['widgetContainer'] = $this->widgetContainer;
        $this->_options['widgetBody'] = $this->widgetBody;
        $this->_options['widgetItem'] = $this->widgetItem;
        $this->_options['limit'] = $this->limit;
        $this->_options['insertButton'] = $this->insertButton;
        $this->_options['deleteButton'] = $this->deleteButton;
        $this->_options['insertPosition'] = $this->insertPosition;
        $this->_options['formId'] = $this->formId;
        $this->_options['min'] = $this->min;
        $this->_options['fields'] = [];

        foreach ($this->formFields as $field) {
            $this->_options['fields'][] = [
                'id' => Html::getInputId($this->model, '[{}]' . $field),
                'name' => Html::getInputName($this->model, '[{}]' . $field)
            ];
        }

        ob_start();
        ob_implicit_flush(false);
    }

    /**
     * @param $view View
     */
    protected function registerOptions($view)
    {
        $encOptions = Json::encode($this->_options);
        $this->_hashVar = DynamicFormWidget::HASH_VAR_BASE_NAME . hash('crc32', $encOptions);
        $view->registerJs("var {$this->_hashVar} = {$encOptions};\n", $view::POS_HEAD);
    }

    /**
     * Registers the needed assets
     */
    public function registerAssets()
    {
        $view = $this->getView();
        DynamicFormAsset::register($view);
        $this->registerOptions($view);

        $js = 'jQuery("#' . $this->formId . '").yiiDynamicForm(' . $this->_hashVar . ');' . "\n";
        $view->registerJs($js, $view::POS_READY);

        // add a click handler for the clone button
        $js = 'jQuery("#' . $this->formId . '").on("click", "' . $this->insertButton . '", function(e) {' . "\n";
        $js .= "    e.preventDefault();\n";
        $js .= '    jQuery(".' . $this->widgetContainer . '").triggerHandler("beforeInsert", [jQuery(this)]);' . "\n";
        $js .= '    jQuery(".' . $this->widgetContainer . '").yiiDynamicForm("addItem", ' . $this->_hashVar . ", e, jQuery(this));\n";
        $js .= "});\n";
        $view->registerJs($js, $view::POS_READY);

        // add a click handler for the remove button
        $js = 'jQuery("#' . $this->formId . '").on("click", "' . $this->deleteButton . '", function(e) {' . "\n";
        $js .= "    e.preventDefault();\n";
        $js .= '    jQuery(".' . $this->widgetContainer . '").yiiDynamicForm("deleteItem", ' . $this->_hashVar . ", e, jQuery(this));\n";
        $js .= "});\n";
        $view->registerJs($js, $view::POS_READY);
    }

    /**
     * @return string|void
     */
    public function run()
    {
        $this->_options['template'] = $this->template;
        $this->registerAssets();
        echo Html::tag('div', ob_get_clean(), ['class' => $this->widgetContainer, 'data-dynamicform' => $this->_hashVar]);
    }
}
