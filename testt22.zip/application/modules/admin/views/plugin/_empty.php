<div class="col-xs-12">
    <div class="box box-solid">
        <div class="box-body">
            <?= Yii::t('app', 'No plugins found.') ?>
        </div>
    </div>
</div>
