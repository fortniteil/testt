<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set('memory_limit', '256M');

/**
 * Require helpers
 */
require_once(__DIR__ . '/helpers.php');
