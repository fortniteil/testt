<?php

namespace app\helpers;

/**
 * @author Alexander Kononenko <contact@hauntd.me>
 * @package app\helpers
 */
class Url extends \yii\helpers\Url
{
}
